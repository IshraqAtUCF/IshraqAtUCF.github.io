import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#f7f6f3',
        surface: '#ffffff',
        border: '#e4e1d9',
        'text-base': '#16162a',
        muted: '#6b6b7a',
        accent: '#2563eb',
        'accent-soft': '#eff6ff',
        sidebar: '#0e1018',
        success: '#16a34a',
        warning: '#ca8a04',
        danger: '#dc2626',
      },
      fontFamily: {
        mono: ['ui-monospace', 'SFMono-Regular', 'monospace'],
      },
    },
  },
  plugins: [],
}
export default config
