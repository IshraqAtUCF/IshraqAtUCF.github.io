'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { formatCurrency } from '@/lib/utils'
import { type Asset, type Liability } from '@/types'
import { Plus, Trash2, X, Pencil, Check } from 'lucide-react'

export default function NetWorthPage() {
  const [assets, setAssets]       = useState<Asset[]>([])
  const [liabilities, setLiabilities] = useState<Liability[]>([])
  const [addingAsset, setAddingAsset] = useState(false)
  const [addingLiab, setAddingLiab]   = useState(false)
  const [form, setForm] = useState({ name: '', type: '', amount: '' })

  useEffect(() => {
    const supabase = createClient()
    async function load() {
      const [{ data: a }, { data: l }] = await Promise.all([
        supabase.from('assets').select('*').order('amount', { ascending: false }),
        supabase.from('liabilities').select('*').order('amount', { ascending: false }),
      ])
      setAssets(a ?? [])
      setLiabilities(l ?? [])
    }
    load()
  }, [])

  async function addAsset() {
    const supabase = createClient()
    const { data } = await supabase.from('assets').insert({
      name: form.name, type: form.type || 'Other', amount: Number(form.amount),
    }).select().single()
    if (data) setAssets(prev => [...prev, data].sort((a, b) => b.amount - a.amount))
    setForm({ name: '', type: '', amount: '' })
    setAddingAsset(false)
  }

  async function addLiability() {
    const supabase = createClient()
    const { data } = await supabase.from('liabilities').insert({
      name: form.name, type: form.type || 'Other', amount: Number(form.amount),
    }).select().single()
    if (data) setLiabilities(prev => [...prev, data].sort((a, b) => b.amount - a.amount))
    setForm({ name: '', type: '', amount: '' })
    setAddingLiab(false)
  }

  async function removeAsset(id: string) {
    const supabase = createClient()
    await supabase.from('assets').delete().eq('id', id)
    setAssets(prev => prev.filter(a => a.id !== id))
  }

  async function removeLiability(id: string) {
    const supabase = createClient()
    await supabase.from('liabilities').delete().eq('id', id)
    setLiabilities(prev => prev.filter(l => l.id !== id))
  }

  const totalAssets      = assets.reduce((s, a) => s + a.amount, 0)
  const totalLiabilities = liabilities.reduce((s, l) => s + l.amount, 0)
  const netWorth         = totalAssets - totalLiabilities

  return (
    <div className="space-y-6">
      <div className="page-header">
        <h1 className="page-title">Net Worth</h1>
        <p className="page-sub">Assets minus liabilities</p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4">
        <div className="card">
          <p className="text-xs text-muted uppercase tracking-wide">Total Assets</p>
          <p className="num text-2xl font-semibold text-success mt-1">{formatCurrency(totalAssets)}</p>
        </div>
        <div className="card">
          <p className="text-xs text-muted uppercase tracking-wide">Total Liabilities</p>
          <p className="num text-2xl font-semibold text-danger mt-1">{formatCurrency(totalLiabilities)}</p>
        </div>
        <div className={`card ${netWorth >= 0 ? 'bg-accent-soft border-blue-100' : 'bg-red-50 border-red-100'}`}>
          <p className="text-xs text-muted uppercase tracking-wide">Net Worth</p>
          <p className={`num text-2xl font-semibold mt-1 ${netWorth >= 0 ? 'text-accent' : 'text-danger'}`}>
            {formatCurrency(netWorth)}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Assets */}
        <Section
          title="Assets"
          total={totalAssets}
          color="text-success"
          items={assets}
          onAdd={() => { setForm({ name: '', type: '', amount: '' }); setAddingAsset(true) }}
          onRemove={removeAsset}
          adding={addingAsset}
          form={form}
          setForm={setForm}
          onSave={addAsset}
          onCancel={() => setAddingAsset(false)}
          typePlaceholder="e.g. Savings, Investment"
        />

        {/* Liabilities */}
        <Section
          title="Liabilities"
          total={totalLiabilities}
          color="text-danger"
          items={liabilities}
          onAdd={() => { setForm({ name: '', type: '', amount: '' }); setAddingLiab(true) }}
          onRemove={removeLiability}
          adding={addingLiab}
          form={form}
          setForm={setForm}
          onSave={addLiability}
          onCancel={() => setAddingLiab(false)}
          typePlaceholder="e.g. Student Loan, Credit Card"
        />
      </div>
    </div>
  )
}

function Section({
  title, total, color, items, onAdd, onRemove,
  adding, form, setForm, onSave, onCancel, typePlaceholder,
}: {
  title: string; total: number; color: string
  items: (Asset | Liability)[]
  onAdd: () => void; onRemove: (id: string) => void
  adding: boolean
  form: { name: string; type: string; amount: string }
  setForm: (f: { name: string; type: string; amount: string }) => void
  onSave: () => void; onCancel: () => void
  typePlaceholder: string
}) {
  return (
    <div className="card space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium">{title}</p>
          <p className={`num text-lg font-semibold ${color}`}>{formatCurrency(total)}</p>
        </div>
        <button className="btn-ghost text-xs" onClick={onAdd}><Plus size={14} /> Add</button>
      </div>

      {adding && (
        <div className="border border-border rounded-lg p-3 space-y-2 bg-bg">
          <input className="input" placeholder="Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} autoFocus />
          <input className="input" placeholder={typePlaceholder} value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} />
          <input className="input num" type="number" placeholder="Amount" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} />
          <div className="flex gap-2">
            <button className="btn-primary flex-1 justify-center" onClick={onSave}><Check size={13} /> Save</button>
            <button className="btn-ghost flex-1 justify-center" onClick={onCancel}>Cancel</button>
          </div>
        </div>
      )}

      <div className="space-y-1">
        {items.length === 0 && !adding && <p className="text-xs text-muted text-center py-2">None added yet</p>}
        {items.map(item => (
          <div key={item.id} className="flex items-center justify-between py-1.5 border-b border-border/50 last:border-0">
            <div>
              <p className="text-sm">{item.name}</p>
              <p className="text-xs text-muted">{item.type}</p>
            </div>
            <div className="flex items-center gap-3">
              <span className={`num text-sm font-medium ${color}`}>{formatCurrency(item.amount)}</span>
              <button onClick={() => onRemove(item.id)} className="text-muted hover:text-danger transition-colors"><Trash2 size={13} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
