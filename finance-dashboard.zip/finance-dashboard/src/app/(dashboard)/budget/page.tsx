'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { formatCurrency, currentMonthStart, monthLabel } from '@/lib/utils'
import { EXPENSE_CATEGORIES, CATEGORY_COLORS, type ExpenseCategory, type Budget, type Expense } from '@/types'
import { Pencil, Check, X } from 'lucide-react'
import { format, addMonths, subMonths, parseISO } from 'date-fns'

// Default budgets pre-loaded with Intel internship numbers
const DEFAULTS: Partial<Record<ExpenseCategory, number>> = {
  'Housing':       2435,
  'Food & Dining': 700,
  'Transportation':300,
  'Utilities':     150,
  'Healthcare':    100,
  'Entertainment': 200,
  'Shopping':      200,
  'Personal Care': 100,
  'Education':     50,
  'Miscellaneous': 200,
}

export default function BudgetPage() {
  const [month, setMonth] = useState(currentMonthStart())
  const [budgets, setBudgets] = useState<Budget[]>([])
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [editing, setEditing] = useState<ExpenseCategory | null>(null)
  const [editVal, setEditVal] = useState('')

  useEffect(() => {
    const supabase = createClient()
    async function load() {
      const [{ data: b }, { data: e }] = await Promise.all([
        supabase.from('budgets').select('*').eq('month', month),
        supabase.from('expenses').select('*').gte('date', month).lt('date',
          format(addMonths(parseISO(month), 1), 'yyyy-MM-dd')),
      ])
      setBudgets(b ?? [])
      setExpenses(e ?? [])
    }
    load()
  }, [month])

  function getBudget(cat: ExpenseCategory): number {
    return budgets.find(b => b.category === cat)?.amount ?? DEFAULTS[cat] ?? 0
  }

  function getSpent(cat: ExpenseCategory): number {
    return expenses.filter(e => e.category === cat).reduce((s, e) => s + e.amount, 0)
  }

  async function saveBudget(cat: ExpenseCategory, amount: number) {
    const supabase = createClient()
    const existing = budgets.find(b => b.category === cat)
    if (existing) {
      await supabase.from('budgets').update({ amount }).eq('id', existing.id)
      setBudgets(prev => prev.map(b => b.id === existing.id ? { ...b, amount } : b))
    } else {
      const { data } = await supabase.from('budgets').insert({ month, category: cat, amount }).select().single()
      if (data) setBudgets(prev => [...prev, data])
    }
    setEditing(null)
  }

  const totalBudget = EXPENSE_CATEGORIES.reduce((s, c) => s + getBudget(c), 0)
  const totalSpent  = EXPENSE_CATEGORIES.reduce((s, c) => s + getSpent(c), 0)

  function prevMonth() { setMonth(format(subMonths(parseISO(month), 1), 'yyyy-MM-dd')) }
  function nextMonth() { setMonth(format(addMonths(parseISO(month), 1), 'yyyy-MM-dd')) }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div className="page-header">
          <h1 className="page-title">Budget</h1>
          <p className="page-sub">{formatCurrency(totalSpent)} spent of {formatCurrency(totalBudget)} budgeted</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={prevMonth} className="btn-ghost px-2">‹</button>
          <span className="text-sm font-medium w-28 text-center">{monthLabel(month)}</span>
          <button onClick={nextMonth} className="btn-ghost px-2">›</button>
        </div>
      </div>

      {/* Overall progress */}
      <div className="card">
        <div className="flex justify-between text-sm mb-2">
          <span className="text-muted">Overall</span>
          <span className="num font-medium">{formatCurrency(totalSpent)} / {formatCurrency(totalBudget)}</span>
        </div>
        <ProgressBar spent={totalSpent} budget={totalBudget} color="#2563eb" />
        <p className="text-xs text-muted mt-2">{formatCurrency(totalBudget - totalSpent)} remaining</p>
      </div>

      {/* Per-category */}
      <div className="space-y-3">
        {EXPENSE_CATEGORIES.map(cat => {
          const budget = getBudget(cat)
          const spent  = getSpent(cat)
          const color  = CATEGORY_COLORS[cat]
          const over   = spent > budget && budget > 0
          return (
            <div key={cat} className="card">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ background: color }} />
                  <span className="text-sm font-medium">{cat}</span>
                  {over && <span className="badge text-danger bg-red-50">over budget</span>}
                </div>
                <div className="flex items-center gap-2">
                  {editing === cat ? (
                    <>
                      <input
                        className="input w-24 py-1 text-right num"
                        type="number"
                        step="1"
                        value={editVal}
                        onChange={e => setEditVal(e.target.value)}
                        autoFocus
                      />
                      <button onClick={() => saveBudget(cat, Number(editVal))} className="text-success hover:opacity-80"><Check size={14} /></button>
                      <button onClick={() => setEditing(null)} className="text-muted hover:text-danger"><X size={14} /></button>
                    </>
                  ) : (
                    <>
                      <span className="num text-sm text-muted">{formatCurrency(spent)} / {formatCurrency(budget)}</span>
                      <button onClick={() => { setEditing(cat); setEditVal(String(budget)) }} className="text-muted hover:text-accent transition-colors">
                        <Pencil size={13} />
                      </button>
                    </>
                  )}
                </div>
              </div>
              <ProgressBar spent={spent} budget={budget} color={over ? '#dc2626' : color} />
            </div>
          )
        })}
      </div>
    </div>
  )
}

function ProgressBar({ spent, budget, color }: { spent: number; budget: number; color: string }) {
  const pct = budget > 0 ? Math.min((spent / budget) * 100, 100) : 0
  return (
    <div className="w-full bg-border rounded-full h-1.5 overflow-hidden">
      <div className="h-full rounded-full transition-all duration-300" style={{ width: `${pct}%`, background: color }} />
    </div>
  )
}
