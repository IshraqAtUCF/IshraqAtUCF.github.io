'use client'
import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { createClient } from '@/lib/supabase/client'
import { formatCurrency, formatDate } from '@/lib/utils'
import { type Income, type IncomeType } from '@/types'
import { Plus, Trash2, X } from 'lucide-react'

const INCOME_TYPES: { value: IncomeType; label: string }[] = [
  { value: 'paycheck',      label: 'Paycheck' },
  { value: 'signing_bonus', label: 'Signing Bonus' },
  { value: 'relocation',    label: 'Relocation' },
  { value: 'other',         label: 'Other' },
]

const TYPE_COLORS: Record<IncomeType, string> = {
  paycheck:      '#2563eb',
  signing_bonus: '#16a34a',
  relocation:    '#ca8a04',
  other:         '#6b7280',
}

const schema = z.object({
  date:         z.string().min(1, 'Required'),
  gross_amount: z.coerce.number().positive('Must be positive'),
  net_amount:   z.coerce.number().positive('Must be positive'),
  type:         z.enum(['paycheck', 'signing_bonus', 'relocation', 'other'] as const),
  notes:        z.string().optional(),
})
type FormData = z.infer<typeof schema>

export default function IncomePage() {
  const [income, setIncome] = useState<Income[]>([])
  const [loading, setLoading] = useState(true)
  const [open, setOpen] = useState(false)

  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { date: new Date().toISOString().slice(0, 10), type: 'paycheck' },
  })

  async function load() {
    const supabase = createClient()
    const { data } = await supabase.from('income').select('*').order('date', { ascending: false })
    setIncome(data ?? [])
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  async function onSubmit(data: FormData) {
    const supabase = createClient()
    await supabase.from('income').insert({
      date: data.date,
      gross_amount: data.gross_amount,
      net_amount: data.net_amount,
      type: data.type,
      notes: data.notes || null,
    })
    reset({ date: new Date().toISOString().slice(0, 10), type: 'paycheck' })
    setOpen(false)
    load()
  }

  async function remove(id: string) {
    const supabase = createClient()
    await supabase.from('income').delete().eq('id', id)
    setIncome(prev => prev.filter(i => i.id !== id))
  }

  const totalGross = income.reduce((s, r) => s + r.gross_amount, 0)
  const totalNet   = income.reduce((s, r) => s + r.net_amount, 0)

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div className="page-header">
          <h1 className="page-title">Income</h1>
          <p className="page-sub">
            {income.length} entries · {formatCurrency(totalNet)} net / {formatCurrency(totalGross)} gross
          </p>
        </div>
        <button className="btn-primary" onClick={() => setOpen(true)}>
          <Plus size={15} /> Add Income
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="card">
          <p className="text-xs text-muted uppercase tracking-wide">Total Gross</p>
          <p className="num text-2xl font-semibold text-text-base mt-1">{formatCurrency(totalGross)}</p>
        </div>
        <div className="card">
          <p className="text-xs text-muted uppercase tracking-wide">Total Net</p>
          <p className="num text-2xl font-semibold text-success mt-1">{formatCurrency(totalNet)}</p>
        </div>
        <div className="card">
          <p className="text-xs text-muted uppercase tracking-wide">Effective Take-home</p>
          <p className="num text-2xl font-semibold text-text-base mt-1">
            {totalGross > 0 ? ((totalNet / totalGross) * 100).toFixed(1) : '0.0'}%
          </p>
        </div>
      </div>

      <div className="card p-0 overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted p-5">Loading…</p>
        ) : income.length === 0 ? (
          <p className="text-sm text-muted p-5 text-center">No income logged yet.</p>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-bg">
              <tr className="text-left text-xs text-muted uppercase tracking-wide">
                <th className="px-5 py-3 font-medium">Date</th>
                <th className="px-5 py-3 font-medium">Type</th>
                <th className="px-5 py-3 font-medium text-right">Gross</th>
                <th className="px-5 py-3 font-medium text-right">Net</th>
                <th className="px-5 py-3 font-medium">Notes</th>
                <th className="px-5 py-3 font-medium" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {income.map(r => (
                <tr key={r.id} className="hover:bg-bg/50">
                  <td className="px-5 py-3 text-muted">{formatDate(r.date)}</td>
                  <td className="px-5 py-3">
                    <span className="badge capitalize" style={{ background: `${TYPE_COLORS[r.type]}18`, color: TYPE_COLORS[r.type] }}>
                      {r.type.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-right num text-muted">{formatCurrency(r.gross_amount)}</td>
                  <td className="px-5 py-3 text-right num font-medium text-success">{formatCurrency(r.net_amount)}</td>
                  <td className="px-5 py-3 text-muted text-xs">{r.notes ?? '—'}</td>
                  <td className="px-5 py-3 text-right">
                    <button onClick={() => remove(r.id)} className="text-muted hover:text-danger transition-colors">
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {open && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4" onClick={() => setOpen(false)}>
          <div className="bg-surface rounded-xl shadow-xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-semibold">Add Income</h2>
              <button onClick={() => setOpen(false)} className="text-muted hover:text-text-base"><X size={18} /></button>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Date</label>
                  <input className="input" type="date" {...register('date')} />
                </div>
                <div>
                  <label className="label">Type</label>
                  <select className="input" {...register('type')}>
                    {INCOME_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Gross ($)</label>
                  <input className="input" type="number" step="0.01" placeholder="0.00" {...register('gross_amount')} />
                  {errors.gross_amount && <p className="text-xs text-danger mt-1">{errors.gross_amount.message}</p>}
                </div>
                <div>
                  <label className="label">Net ($)</label>
                  <input className="input" type="number" step="0.01" placeholder="0.00" {...register('net_amount')} />
                  {errors.net_amount && <p className="text-xs text-danger mt-1">{errors.net_amount.message}</p>}
                </div>
              </div>

              <div>
                <label className="label">Notes</label>
                <input className="input" placeholder="e.g. Pay period May 1–15" {...register('notes')} />
              </div>

              <div className="flex gap-3 pt-1">
                <button type="button" className="btn-ghost flex-1 justify-center" onClick={() => setOpen(false)}>Cancel</button>
                <button type="submit" className="btn-primary flex-1 justify-center" disabled={isSubmitting}>
                  {isSubmitting ? 'Saving…' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
