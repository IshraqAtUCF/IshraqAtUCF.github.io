'use client'
import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { createClient } from '@/lib/supabase/client'
import { formatCurrency, formatDate } from '@/lib/utils'
import { EXPENSE_CATEGORIES, CATEGORY_COLORS, type Expense, type ExpenseCategory } from '@/types'
import { Plus, Trash2, X } from 'lucide-react'

const schema = z.object({
  date:        z.string().min(1, 'Required'),
  amount:      z.coerce.number().positive('Must be positive'),
  category:    z.enum(EXPENSE_CATEGORIES as [ExpenseCategory, ...ExpenseCategory[]]),
  description: z.string().optional(),
  merchant:    z.string().optional(),
})
type FormData = z.infer<typeof schema>

export default function ExpensesPage() {
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [loading, setLoading]   = useState(true)
  const [open, setOpen]         = useState(false)
  const [filter, setFilter]     = useState<ExpenseCategory | 'All'>('All')

  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { date: new Date().toISOString().slice(0, 10) },
  })

  async function load() {
    const supabase = createClient()
    const { data } = await supabase.from('expenses').select('*').order('date', { ascending: false })
    setExpenses(data ?? [])
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  async function onSubmit(data: FormData) {
    const supabase = createClient()
    await supabase.from('expenses').insert({
      date: data.date,
      amount: data.amount,
      category: data.category,
      description: data.description || null,
      merchant: data.merchant || null,
    })
    reset({ date: new Date().toISOString().slice(0, 10) })
    setOpen(false)
    load()
  }

  async function remove(id: string) {
    const supabase = createClient()
    await supabase.from('expenses').delete().eq('id', id)
    setExpenses(prev => prev.filter(e => e.id !== id))
  }

  const visible = filter === 'All' ? expenses : expenses.filter(e => e.category === filter)
  const total   = visible.reduce((s, e) => s + e.amount, 0)

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div className="page-header">
          <h1 className="page-title">Expenses</h1>
          <p className="page-sub">{visible.length} entries · {formatCurrency(total)} total</p>
        </div>
        <button className="btn-primary" onClick={() => setOpen(true)}>
          <Plus size={15} /> Add Expense
        </button>
      </div>

      {/* Category filter */}
      <div className="flex flex-wrap gap-2">
        {(['All', ...EXPENSE_CATEGORIES] as const).map(cat => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors
              ${filter === cat ? 'bg-accent text-white' : 'bg-surface border border-border text-muted hover:text-text-base'}`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="card p-0 overflow-hidden">
        {loading ? (
          <p className="text-sm text-muted p-5">Loading…</p>
        ) : visible.length === 0 ? (
          <p className="text-sm text-muted p-5 text-center">No expenses yet. Add your first one.</p>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-bg">
              <tr className="text-left text-xs text-muted uppercase tracking-wide">
                <th className="px-5 py-3 font-medium">Date</th>
                <th className="px-5 py-3 font-medium">Description</th>
                <th className="px-5 py-3 font-medium">Merchant</th>
                <th className="px-5 py-3 font-medium">Category</th>
                <th className="px-5 py-3 font-medium text-right">Amount</th>
                <th className="px-5 py-3 font-medium" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {visible.map(e => (
                <tr key={e.id} className="hover:bg-bg/50">
                  <td className="px-5 py-3 text-muted">{formatDate(e.date)}</td>
                  <td className="px-5 py-3">{e.description ?? '—'}</td>
                  <td className="px-5 py-3 text-muted">{e.merchant ?? '—'}</td>
                  <td className="px-5 py-3">
                    <span className="badge" style={{ background: `${CATEGORY_COLORS[e.category]}18`, color: CATEGORY_COLORS[e.category] }}>
                      {e.category}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-right num font-medium">{formatCurrency(e.amount)}</td>
                  <td className="px-5 py-3 text-right">
                    <button onClick={() => remove(e.id)} className="text-muted hover:text-danger transition-colors">
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Add modal */}
      {open && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4" onClick={() => setOpen(false)}>
          <div className="bg-surface rounded-xl shadow-xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-semibold">Add Expense</h2>
              <button onClick={() => setOpen(false)} className="text-muted hover:text-text-base"><X size={18} /></button>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Date</label>
                  <input className="input" type="date" {...register('date')} />
                  {errors.date && <p className="text-xs text-danger mt-1">{errors.date.message}</p>}
                </div>
                <div>
                  <label className="label">Amount ($)</label>
                  <input className="input" type="number" step="0.01" placeholder="0.00" {...register('amount')} />
                  {errors.amount && <p className="text-xs text-danger mt-1">{errors.amount.message}</p>}
                </div>
              </div>

              <div>
                <label className="label">Category</label>
                <select className="input" {...register('category')}>
                  {EXPENSE_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>

              <div>
                <label className="label">Merchant</label>
                <input className="input" placeholder="e.g. Safeway" {...register('merchant')} />
              </div>

              <div>
                <label className="label">Description</label>
                <input className="input" placeholder="Optional note" {...register('description')} />
              </div>

              <div className="flex gap-3 pt-1">
                <button type="button" className="btn-ghost flex-1 justify-center" onClick={() => setOpen(false)}>Cancel</button>
                <button type="submit" className="btn-primary flex-1 justify-center" disabled={isSubmitting}>
                  {isSubmitting ? 'Saving…' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
