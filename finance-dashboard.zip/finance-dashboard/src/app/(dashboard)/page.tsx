'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { formatCurrency, monthLabel } from '@/lib/utils'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts'
import { type Expense, type Income, CATEGORY_COLORS } from '@/types'
import { TrendingUp, TrendingDown, DollarSign, Percent } from 'lucide-react'

interface MonthBucket { month: string; income: number; expenses: number }

export default function OverviewPage() {
  const [income, setIncome] = useState<Income[]>([])
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const supabase = createClient()
    async function load() {
      const [{ data: inc }, { data: exp }] = await Promise.all([
        supabase.from('income').select('*').order('date', { ascending: true }),
        supabase.from('expenses').select('*').order('date', { ascending: true }),
      ])
      setIncome(inc ?? [])
      setExpenses(exp ?? [])
      setLoading(false)
    }
    load()
  }, [])

  const totalIncome   = income.reduce((s, r) => s + r.net_amount, 0)
  const totalExpenses = expenses.reduce((s, r) => s + r.amount, 0)
  const netSavings    = totalIncome - totalExpenses
  const savingsRate   = totalIncome > 0 ? (netSavings / totalIncome) * 100 : 0

  // Monthly bar chart data
  const monthMap: Record<string, MonthBucket> = {}
  income.forEach(r => {
    const m = r.date.slice(0, 7)
    if (!monthMap[m]) monthMap[m] = { month: monthLabel(m + '-01'), income: 0, expenses: 0 }
    monthMap[m].income += r.net_amount
  })
  expenses.forEach(r => {
    const m = r.date.slice(0, 7)
    if (!monthMap[m]) monthMap[m] = { month: monthLabel(m + '-01'), income: 0, expenses: 0 }
    monthMap[m].expenses += r.amount
  })
  const monthData = Object.values(monthMap).slice(-6)

  // Category pie data (all time)
  const catMap: Record<string, number> = {}
  expenses.forEach(r => { catMap[r.category] = (catMap[r.category] ?? 0) + r.amount })
  const catData = Object.entries(catMap)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)

  // Recent expenses
  const recent = [...expenses].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6)

  if (loading) return <div className="text-muted text-sm">Loading…</div>

  return (
    <div className="space-y-6">
      <div className="page-header">
        <h1 className="page-title">Overview</h1>
        <p className="page-sub">Intel internship period · all time</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Total Earned" value={formatCurrency(totalIncome)} icon={TrendingUp} color="text-success" />
        <StatCard label="Total Spent"  value={formatCurrency(totalExpenses)} icon={TrendingDown} color="text-danger" />
        <StatCard label="Net Savings"  value={formatCurrency(netSavings)} icon={DollarSign} color={netSavings >= 0 ? 'text-accent' : 'text-danger'} />
        <StatCard label="Savings Rate" value={`${savingsRate.toFixed(1)}%`} icon={Percent} color="text-accent" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Monthly bar chart */}
        <div className="card lg:col-span-2">
          <p className="text-sm font-medium text-text-base mb-4">Income vs Expenses</p>
          {monthData.length === 0 ? (
            <p className="text-sm text-muted py-8 text-center">No data yet</p>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={monthData} barGap={2}>
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#6b6b7a' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#6b6b7a' }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v/1000).toFixed(0)}k`} />
                <Tooltip formatter={(v: number) => formatCurrency(v)} contentStyle={{ fontSize: 12, border: '1px solid #e4e1d9', borderRadius: 6 }} />
                <Bar dataKey="income"   name="Income"   fill="#2563eb" radius={[3,3,0,0]} />
                <Bar dataKey="expenses" name="Expenses" fill="#dc2626" radius={[3,3,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Category pie */}
        <div className="card">
          <p className="text-sm font-medium text-text-base mb-4">By Category</p>
          {catData.length === 0 ? (
            <p className="text-sm text-muted py-8 text-center">No expenses yet</p>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={catData} dataKey="value" cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={2}>
                  {catData.map(entry => (
                    <Cell key={entry.name} fill={CATEGORY_COLORS[entry.name as keyof typeof CATEGORY_COLORS] ?? '#6b7280'} />
                  ))}
                </Pie>
                <Legend iconSize={8} iconType="circle" wrapperStyle={{ fontSize: 11 }} />
                <Tooltip formatter={(v: number) => formatCurrency(v)} contentStyle={{ fontSize: 12, border: '1px solid #e4e1d9', borderRadius: 6 }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Recent transactions */}
      <div className="card">
        <p className="text-sm font-medium text-text-base mb-4">Recent Expenses</p>
        {recent.length === 0 ? (
          <p className="text-sm text-muted py-4 text-center">No expenses logged yet</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-muted uppercase tracking-wide border-b border-border">
                <th className="pb-2 font-medium">Date</th>
                <th className="pb-2 font-medium">Description</th>
                <th className="pb-2 font-medium">Category</th>
                <th className="pb-2 font-medium text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {recent.map(e => (
                <tr key={e.id}>
                  <td className="py-2.5 text-muted">{e.date}</td>
                  <td className="py-2.5">{e.description ?? e.merchant ?? '—'}</td>
                  <td className="py-2.5">
                    <span className="badge" style={{ background: `${CATEGORY_COLORS[e.category]}18`, color: CATEGORY_COLORS[e.category] }}>
                      {e.category}
                    </span>
                  </td>
                  <td className="py-2.5 text-right num font-medium">{formatCurrency(e.amount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

function StatCard({ label, value, icon: Icon, color }: { label: string; value: string; icon: React.ElementType; color: string }) {
  return (
    <div className="card flex items-start gap-3">
      <div className={`mt-0.5 ${color}`}><Icon size={18} /></div>
      <div>
        <p className="text-xs text-muted uppercase tracking-wide">{label}</p>
        <p className={`num text-xl font-semibold mt-0.5 ${color}`}>{value}</p>
      </div>
    </div>
  )
}
