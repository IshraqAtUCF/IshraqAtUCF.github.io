'use client'
import { useState } from 'react'
import { formatCurrency } from '@/lib/utils'

interface TaxResult {
  federal: number
  california: number
  socialSecurity: number
  medicare: number
  caSDI: number
  totalTax: number
  netAnnual: number
  netMonthly: number
  netBiweekly: number
  effectiveRate: number
}

function calculateTaxes(grossAnnual: number, preTax401k: number, relocProtected: number): TaxResult {
  const taxableGross = grossAnnual - preTax401k - relocProtected

  // Federal MFJ 2024
  const fedStdDeduction = 29200
  const fedTaxable = Math.max(0, taxableGross - fedStdDeduction)
  let federal = 0
  const fedBrackets = [[23200, 0.10], [94300, 0.12], [201050, 0.22], [383900, 0.24], [487450, 0.32], [731200, 0.35], [Infinity, 0.37]] as const
  let prev = 0
  for (const [limit, rate] of fedBrackets) {
    if (fedTaxable <= prev) break
    federal += (Math.min(fedTaxable, limit) - prev) * rate
    prev = limit
  }

  // California MFJ 2024
  const caStdDeduction = 10726
  const caTaxable = Math.max(0, taxableGross - caStdDeduction)
  let california = 0
  const caBrackets = [[20824, 0.01], [49368, 0.02], [77918, 0.04], [108162, 0.06], [136700, 0.08], [698274, 0.093], [837922, 0.103], [1000000, 0.113], [Infinity, 0.123]] as const
  let cprev = 0
  for (const [limit, rate] of caBrackets) {
    if (caTaxable <= cprev) break
    california += (Math.min(caTaxable, limit) - cprev) * rate
    cprev = limit
  }

  // FICA (on gross, not reduced by deductions)
  const ficaBase = Math.min(grossAnnual, 168600)
  const socialSecurity = ficaBase * 0.062
  const medicare = grossAnnual * 0.0145

  // CA SDI 2024 (1.1% uncapped)
  const caSDI = grossAnnual * 0.011

  const totalTax = federal + california + socialSecurity + medicare + caSDI
  const netAnnual = grossAnnual - totalTax - preTax401k
  const effectiveRate = grossAnnual > 0 ? (totalTax / grossAnnual) * 100 : 0

  return {
    federal, california, socialSecurity, medicare, caSDI,
    totalTax, netAnnual,
    netMonthly: netAnnual / 12,
    netBiweekly: netAnnual / 26,
    effectiveRate,
  }
}

export default function TaxPage() {
  const [gross, setGross] = useState(53500)
  const [k401, setK401] = useState(0)
  const [reloc, setReloc] = useState(7000)

  const result = calculateTaxes(gross, k401, reloc)

  return (
    <div className="space-y-6">
      <div className="page-header">
        <h1 className="page-title">Tax Calculator</h1>
        <p className="page-sub">California + Federal · Married Filing Jointly · 2024</p>
      </div>

      {/* Inputs */}
      <div className="card">
        <p className="text-sm font-medium mb-4">Your Numbers</p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div>
            <label className="label">Annual Gross Salary ($)</label>
            <input className="input num" type="number" value={gross} onChange={e => setGross(Number(e.target.value))} />
            <p className="text-xs text-muted mt-1">Intel offer: $53,500</p>
          </div>
          <div>
            <label className="label">Pre-tax 401(k) ($)</label>
            <input className="input num" type="number" value={k401} onChange={e => setK401(Number(e.target.value))} />
          </div>
          <div>
            <label className="label">Tax-Protected Relocation ($)</label>
            <input className="input num" type="number" value={reloc} onChange={e => setReloc(Number(e.target.value))} />
            <p className="text-xs text-muted mt-1">Intel relocation: $7,000</p>
          </div>
        </div>
      </div>

      {/* Results — take-home summary */}
      <div className="grid grid-cols-3 gap-4">
        <div className="card bg-accent-soft border-blue-100">
          <p className="text-xs text-accent uppercase tracking-wide font-medium">Net Annual</p>
          <p className="num text-2xl font-semibold text-text-base mt-1">{formatCurrency(result.netAnnual)}</p>
        </div>
        <div className="card">
          <p className="text-xs text-muted uppercase tracking-wide">Net Monthly</p>
          <p className="num text-2xl font-semibold text-text-base mt-1">{formatCurrency(result.netMonthly)}</p>
        </div>
        <div className="card">
          <p className="text-xs text-muted uppercase tracking-wide">Net Biweekly</p>
          <p className="num text-2xl font-semibold text-text-base mt-1">{formatCurrency(result.netBiweekly)}</p>
        </div>
      </div>

      {/* Tax breakdown */}
      <div className="card">
        <p className="text-sm font-medium mb-4">Tax Breakdown</p>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-muted uppercase tracking-wide border-b border-border">
              <th className="pb-2 font-medium">Component</th>
              <th className="pb-2 font-medium text-right">Rate</th>
              <th className="pb-2 font-medium text-right">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            <TaxRow label="Federal Income Tax (MFJ)"   rate={`${((result.federal / gross) * 100).toFixed(1)}%`} amount={result.federal} />
            <TaxRow label="California State Tax (MFJ)" rate={`${((result.california / gross) * 100).toFixed(1)}%`} amount={result.california} />
            <TaxRow label="Social Security (6.2%)"     rate="6.2%" amount={result.socialSecurity} />
            <TaxRow label="Medicare (1.45%)"           rate="1.45%" amount={result.medicare} />
            <TaxRow label="CA SDI (1.1%)"              rate="1.1%" amount={result.caSDI} />
          </tbody>
          <tfoot>
            <tr className="border-t-2 border-border font-semibold">
              <td className="pt-3">Total Tax</td>
              <td className="pt-3 text-right text-danger">{result.effectiveRate.toFixed(1)}% effective</td>
              <td className="pt-3 text-right num text-danger">{formatCurrency(result.totalTax)}</td>
            </tr>
          </tfoot>
        </table>
      </div>

      <p className="text-xs text-muted">
        Estimates only. Uses 2024 standard deductions and tax brackets.
        Does not account for tax credits, itemized deductions, or other income.
      </p>
    </div>
  )
}

function TaxRow({ label, rate, amount }: { label: string; rate: string; amount: number }) {
  return (
    <tr>
      <td className="py-2.5">{label}</td>
      <td className="py-2.5 text-right text-muted num">{rate}</td>
      <td className="py-2.5 text-right num font-medium">{formatCurrency(amount)}</td>
    </tr>
  )
}
