'use client'
import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { formatCurrency, formatDate } from '@/lib/utils'
import { type Goal } from '@/types'
import { Plus, Trash2, X, Pencil, Check } from 'lucide-react'
import { differenceInDays, parseISO } from 'date-fns'

export default function GoalsPage() {
  const [goals, setGoals] = useState<Goal[]>([])
  const [open, setOpen] = useState(false)
  const [editingProgress, setEditingProgress] = useState<string | null>(null)
  const [progressVal, setProgressVal] = useState('')
  const [form, setForm] = useState({ name: '', target_amount: '', deadline: '' })

  useEffect(() => {
    const supabase = createClient()
    supabase.from('goals').select('*').order('created_at').then(({ data }) => setGoals(data ?? []))
  }, [])

  async function addGoal() {
    const supabase = createClient()
    const { data } = await supabase.from('goals').insert({
      name: form.name,
      target_amount: Number(form.target_amount),
      current_amount: 0,
      deadline: form.deadline || null,
    }).select().single()
    if (data) setGoals(prev => [...prev, data])
    setForm({ name: '', target_amount: '', deadline: '' })
    setOpen(false)
  }

  async function updateProgress(id: string, amount: number) {
    const supabase = createClient()
    await supabase.from('goals').update({ current_amount: amount }).eq('id', id)
    setGoals(prev => prev.map(g => g.id === id ? { ...g, current_amount: amount } : g))
    setEditingProgress(null)
  }

  async function removeGoal(id: string) {
    const supabase = createClient()
    await supabase.from('goals').delete().eq('id', id)
    setGoals(prev => prev.filter(g => g.id !== id))
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div className="page-header">
          <h1 className="page-title">Goals</h1>
          <p className="page-sub">{goals.length} active {goals.length === 1 ? 'goal' : 'goals'}</p>
        </div>
        <button className="btn-primary" onClick={() => setOpen(true)}>
          <Plus size={15} /> Add Goal
        </button>
      </div>

      {goals.length === 0 ? (
        <div className="card text-center py-12">
          <p className="text-muted text-sm">No goals yet. Set your first savings target.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {goals.map(goal => {
            const pct      = goal.target_amount > 0 ? Math.min((goal.current_amount / goal.target_amount) * 100, 100) : 0
            const done     = pct >= 100
            const daysLeft = goal.deadline ? differenceInDays(parseISO(goal.deadline), new Date()) : null
            return (
              <div key={goal.id} className={`card space-y-3 ${done ? 'border-success/30 bg-green-50/30' : ''}`}>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm font-medium">{goal.name}</p>
                    {goal.deadline && (
                      <p className="text-xs text-muted mt-0.5">
                        {daysLeft !== null && daysLeft >= 0 ? `${daysLeft}d left · ` : 'Past deadline · '}
                        due {formatDate(goal.deadline)}
                      </p>
                    )}
                  </div>
                  <button onClick={() => removeGoal(goal.id)} className="text-muted hover:text-danger transition-colors shrink-0">
                    <Trash2 size={13} />
                  </button>
                </div>

                <div>
                  <div className="flex justify-between text-xs text-muted mb-1.5">
                    <span className="num">{formatCurrency(goal.current_amount)} saved</span>
                    <span className="num">{formatCurrency(goal.target_amount)} target</span>
                  </div>
                  <div className="w-full bg-border rounded-full h-2 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${pct}%`, background: done ? '#16a34a' : '#2563eb' }}
                    />
                  </div>
                  <p className="text-xs text-muted mt-1">{pct.toFixed(1)}% complete</p>
                </div>

                {/* Update progress */}
                {editingProgress === goal.id ? (
                  <div className="flex items-center gap-2">
                    <input
                      className="input num py-1 text-sm"
                      type="number"
                      step="0.01"
                      value={progressVal}
                      onChange={e => setProgressVal(e.target.value)}
                      autoFocus
                    />
                    <button onClick={() => updateProgress(goal.id, Number(progressVal))} className="text-success hover:opacity-80">
                      <Check size={15} />
                    </button>
                    <button onClick={() => setEditingProgress(null)} className="text-muted hover:text-danger">
                      <X size={15} />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => { setEditingProgress(goal.id); setProgressVal(String(goal.current_amount)) }}
                    className="btn-ghost text-xs w-full justify-center"
                  >
                    <Pencil size={12} /> Update Progress
                  </button>
                )}
              </div>
            )
          })}
        </div>
      )}

      {open && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4" onClick={() => setOpen(false)}>
          <div className="bg-surface rounded-xl shadow-xl w-full max-w-sm p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-semibold">New Goal</h2>
              <button onClick={() => setOpen(false)} className="text-muted hover:text-text-base"><X size={18} /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="label">Goal Name</label>
                <input className="input" placeholder="e.g. Emergency Fund" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} autoFocus />
              </div>
              <div>
                <label className="label">Target Amount ($)</label>
                <input className="input num" type="number" placeholder="0.00" value={form.target_amount} onChange={e => setForm({ ...form, target_amount: e.target.value })} />
              </div>
              <div>
                <label className="label">Deadline (optional)</label>
                <input className="input" type="date" value={form.deadline} onChange={e => setForm({ ...form, deadline: e.target.value })} />
              </div>
              <div className="flex gap-3 pt-1">
                <button className="btn-ghost flex-1 justify-center" onClick={() => setOpen(false)}>Cancel</button>
                <button className="btn-primary flex-1 justify-center" onClick={addGoal} disabled={!form.name || !form.target_amount}>
                  Create Goal
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
