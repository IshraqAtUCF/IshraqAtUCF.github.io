'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import {
  LayoutDashboard, TrendingUp, CreditCard, PieChart,
  Calculator, BarChart3, Target, LogOut,
} from 'lucide-react'
import { cn } from '@/lib/utils'

const nav = [
  { href: '/',           label: 'Overview',  icon: LayoutDashboard },
  { href: '/income',     label: 'Income',    icon: TrendingUp },
  { href: '/expenses',   label: 'Expenses',  icon: CreditCard },
  { href: '/budget',     label: 'Budget',    icon: PieChart },
  { href: '/tax',        label: 'Tax',       icon: Calculator },
  { href: '/net-worth',  label: 'Net Worth', icon: BarChart3 },
  { href: '/goals',      label: 'Goals',     icon: Target },
]

export default function Sidebar() {
  const pathname = usePathname()
  const router = useRouter()

  async function signOut() {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  return (
    <aside className="fixed inset-y-0 left-0 w-56 bg-sidebar flex flex-col z-10">
      {/* Brand */}
      <div className="px-5 py-5 border-b border-white/5">
        <p className="text-white text-sm font-semibold tracking-tight">Finance</p>
        <p className="text-white/30 text-xs mt-0.5">Intel Period</p>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {nav.map(({ href, label, icon: Icon }) => {
          const active = pathname === href
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                'flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors',
                active
                  ? 'bg-white/10 text-white'
                  : 'text-white/50 hover:text-white/80 hover:bg-white/5'
              )}
            >
              <Icon size={15} />
              {label}
            </Link>
          )
        })}
      </nav>

      {/* Sign out */}
      <div className="px-3 py-4 border-t border-white/5">
        <button
          onClick={signOut}
          className="flex items-center gap-3 px-3 py-2 w-full rounded-md text-sm
                     text-white/40 hover:text-white/70 hover:bg-white/5 transition-colors"
        >
          <LogOut size={15} />
          Sign out
        </button>
      </div>
    </aside>
  )
}
