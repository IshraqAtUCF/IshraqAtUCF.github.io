export type IncomeType = 'paycheck' | 'signing_bonus' | 'relocation' | 'other'

export type ExpenseCategory =
  | 'Housing'
  | 'Food & Dining'
  | 'Transportation'
  | 'Utilities'
  | 'Healthcare'
  | 'Entertainment'
  | 'Shopping'
  | 'Personal Care'
  | 'Education'
  | 'Miscellaneous'

export interface Income {
  id: string
  date: string
  gross_amount: number
  net_amount: number
  type: IncomeType
  notes: string | null
  created_at: string
}

export interface Expense {
  id: string
  date: string
  amount: number
  category: ExpenseCategory
  description: string | null
  merchant: string | null
  created_at: string
}

export interface Budget {
  id: string
  month: string
  category: ExpenseCategory
  amount: number
}

export interface Asset {
  id: string
  name: string
  type: string
  amount: number
  updated_at: string
}

export interface Liability {
  id: string
  name: string
  type: string
  amount: number
  updated_at: string
}

export interface Goal {
  id: string
  name: string
  target_amount: number
  current_amount: number
  deadline: string | null
  created_at: string
}

export const EXPENSE_CATEGORIES: ExpenseCategory[] = [
  'Housing',
  'Food & Dining',
  'Transportation',
  'Utilities',
  'Healthcare',
  'Entertainment',
  'Shopping',
  'Personal Care',
  'Education',
  'Miscellaneous',
]

export const CATEGORY_COLORS: Record<ExpenseCategory, string> = {
  'Housing':       '#2563eb',
  'Food & Dining': '#16a34a',
  'Transportation':'#ca8a04',
  'Utilities':     '#9333ea',
  'Healthcare':    '#dc2626',
  'Entertainment': '#0891b2',
  'Shopping':      '#db2777',
  'Personal Care': '#65a30d',
  'Education':     '#ea580c',
  'Miscellaneous': '#6b7280',
}
